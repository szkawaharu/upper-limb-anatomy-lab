上肢3D解剖ラボ v0.3 — iPhoneプレビュー対策版

・index.html：骨の3D操作サイト本体（外部ライブラリ不要）
・README.txt：この説明

【重要】
ChatGPT上でHTMLファイルをタップしたときに表示されるiPhoneのファイルプレビューでは、JavaScriptやWebGLが実行されない場合があります。操作パネルは表示されるのに骨が空白になるのは、この制限が原因と考えられます。

v0.3では、JavaScriptが動かない場合にも骨格の「静止プレビュー」を表示するようにしました。ただし、静止プレビューだけでは3D操作できません。

【実際にスマホで操作する方法 — GitHub Pages】
1. GitHubでWeb公開用リポジトリを作成する（公開される前提です）。
2. このZIP内のindex.htmlをリポジトリの最上位にアップロードします。
3. リポジトリ Settings → Pages → Build and deployment → Deploy from a branch → main / (root) → Save。
4. 発行されたHTTPSの公開URLをSafariで開きます。

公式手順：https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

【主な機能】
5種の骨の個別表示/非表示、腕の挙上、挙上面の変更、肩甲骨・鎖骨の連動、肘屈曲、前腕回内・回外、筋肉・腱の概形、指ドラッグでの360度回転、ピンチ拡大。

【限界】
骨形状は手続き生成による解剖学的近似です。CT由来の高精細骨モデルではなく、靱帯拘束・骨衝突・筋力計算・正確な肩甲上腕リズムも未実装です。
